# Quick Start Guide

This guide helps you quickly navigate and use the evaluation results.

## 🎯 What Do You Want to Do?

### Option 1: Understand the Experiment

**Start here**: `EXPERIMENT_REPORT.md`

- Section 1: Executive Summary (2 minutes)
- Section 2: Experiment Design (5 minutes)
- Section 3: Results Overview (10 minutes)

**Key takeaway**: Multi-agent DAG scheduling needs ≥12 tasks to overcome overhead.

---

### Option 2: Get Performance Numbers

**Start here**: `tables/table1_performance_comparison.md`

Quick facts:
- Overall speedup: 1.23×
- Best case: 1.57× (os_user_analysis, 3 tasks)
- Worst case: 0.70× (db_product_sales, 2 tasks)
- Success rate: 100% (41/41 tasks)

---

### Option 3: Analyze Data Yourself

**Start here**: `raw_data/summary.csv`

Open in Excel/Numbers/Google Sheets:
1. Import `summary.csv`
2. Create pivot tables or charts
3. All 5 test results in one file

Python users:
```python
import pandas as pd
df = pd.read_csv('raw_data/summary.csv')
df.plot(x='tasks', y='speedup', kind='scatter')
```

---

### Option 4: Use in Academic Paper

**For LaTeX users**:
1. Go to `tables/table1_performance_comparison.md`
2. Copy the LaTeX code block
3. Paste into your paper
4. Add `\usepackage{booktabs}` to preamble

**For Word users**:
1. Tables are in Markdown format
2. Copy-paste the table
3. Or convert with Pandoc

**Citation format** (see README.md):
- Cite as: "Multi-Agent Scheduler Evaluation (2025)"
- Reference: Day 7 End-to-End Evaluation
- Dataset: 5 groups, 41 tasks, 100% success

---

## 📊 File Navigation Map

```
What you want → Where to look

Overall understanding → EXPERIMENT_REPORT.md
Performance numbers → tables/table1_performance_comparison.md
Scalability trends → tables/table3_scalability_analysis.md
Raw data analysis → raw_data/summary.csv
Timeout impact → tables/table4_timeout_impact.md
Complete metrics → tables/table5_detailed_metrics.md
Experiment config → raw_data/metadata.json
Data usage help → raw_data/README.md
```

---

## 🚀 5-Minute Speed Run

1. **Skim** `EXPERIMENT_REPORT.md` Executive Summary (1 min)
2. **Read** `tables/table1_performance_comparison.md` (2 min)
3. **Check** `raw_data/summary.csv` in Excel (2 min)

You now know:
- ✅ What was tested (5 groups, 41 tasks)
- ✅ Main findings (≥12 tasks threshold)
- ✅ Performance metrics (1.23× average speedup)

---

## 💡 Tips

### For Researchers
- All text files are UTF-8 encoded (cross-platform)
- JSON files can be loaded in any language
- CSV uses standard format (compatible with Excel/R/Python)

### For Students
- Read Executive Summary first
- Tables have "Key Findings" sections
- Experiment Report has paper writing guide

### For Practitioners
- Check table3 for task scale recommendations
- table4 shows why timeout matters
- metadata.json has tool stack details

---

## ❓ Common Questions

**Q: Can I re-run the experiments?**
A: Yes, but requires:
- Claude CLI installed
- AgentBench framework
- ~45 minutes execution time
- See metadata.json for exact config

**Q: What if I need more statistical rigor?**
A: Current data is single-run. For publication:
- Run each test 3-5 times
- Calculate mean/std/confidence intervals
- See "Limitations" in EXPERIMENT_REPORT.md

**Q: Can I use this data in my paper?**
A: Yes! All results are shareable. Please cite appropriately.

**Q: What format are the tables?**
A: Dual format - Markdown (readable) + LaTeX (copy-paste to paper)

**Q: How do I open .md files?**
A:
- Any text editor (Notepad, TextEdit, VS Code)
- Markdown viewer (Typora, Mark Text)
- GitHub/GitLab (renders automatically)

---

**Questions not answered here?**
→ Check `EXPERIMENT_REPORT.md` Section 9 (FAQ)
→ Review `raw_data/README.md` for data specifics
